import React, { useState } from 'react';
import '../by/GpaypaymentPage.css';

export default function Phonepay() {
    const [upiId, setUpiId] = useState('');
    const [amount, setAmount] = useState('');

    const handleSubmit = (event) => {
        event.preventDefault();
        if (upiId && amount) { 
            localStorage.setItem('PhonePayPaymentData', JSON.stringify({ upiId, amount }));
            alert(`request success`);
        } else {
            alert('Please enter both UPI ID and amount.');
        }
    };

    return (
        <div className='container'>
            <div className="Gpay-container">
                <h1>Phone Pay Payment</h1>
                <form className="payment-form" onSubmit={handleSubmit}>
                    <div className="form-group">
                        <label htmlFor="upiId">UPI ID:</label>
                        <input
                            type="text"
                            id="upiId"
                            placeholder="Enter your UPI ID"
                            value={upiId}
                            onChange={(e) => setUpiId(e.target.value)}
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="amount">Amount</label>
                        <input
                            type="number"
                            id="amount"
                            placeholder="Enter amount"
                            value={amount}
                            onChange={(e) => setAmount(e.target.value)}
                        />
                    </div>
                    <button type="submit" className="pay-button">
                        <b>Pay with Phone Pay</b>
                    </button>
                </form>
            </div>
        </div>
    );
}
